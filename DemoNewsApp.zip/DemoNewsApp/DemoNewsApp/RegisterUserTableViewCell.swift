//
//  RegisterUserTableViewCell.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 28/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import UIKit

class RegisterUserTableViewCell: UITableViewCell,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var infoTxtFld: UITextField!
    
    let pickerView = UIPickerView()
    var optionsArray = [String]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCellWithInfo(rowObj: RowObject) {
        
        optionsArray.removeAll()
        for options in rowObj.options {
            optionsArray.append(options.label)
        }
        
        if let labelText = rowObj.placeHolder, let phText = rowObj.placeHolder,let type = rowObj.type {
            infoLabel.text = labelText
            infoTxtFld.placeholder = phText
            
            if(type == "select") {
                infoTxtFld.inputView = pickerView
                pickerView.delegate = self
                pickerView.dataSource = self
                setTextFieldIcon()
                configureAccessoryView()
            }
        }
    }
    
    func setTextFieldIcon() {
        infoTxtFld.rightViewMode = UITextFieldViewMode.always
        let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 8, height: 8))
        imageView.image = UIImage(named: "dropDown")
        infoTxtFld.rightView = imageView
    }
    
    func configureAccessoryView() {
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .default
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButtonAction))
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        infoTxtFld.inputAccessoryView = doneToolbar
    }
    
    @objc func doneButtonAction(){
        infoTxtFld.resignFirstResponder()
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return optionsArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return optionsArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        infoTxtFld.text = optionsArray[row]
    }
}








