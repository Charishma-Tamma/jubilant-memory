//
//  RegisterViewController.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 28/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {

    @IBOutlet weak var userDetailsTable: UITableView!
    var toRegisterInfo = [RowObject]()
    
    var dict = [String:String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(handleCancelAction))
        prepareUI()
        renderLayout()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func prepareUI() {
        
        userDetailsTable.tableFooterView = UIView()
    }
    
    @objc func handleCancelAction() {
        self.dismiss(animated: true, completion: nil)
    }
    
    func renderLayout() {
        if let jsonDict = GSConnection.shared.readJson() {
            if let rowInfo = jsonDict["fields"] as? [[String:Any]] {
                for each in rowInfo {
                    toRegisterInfo.append(RowObject(fieldInfo: each))
                }
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return toRegisterInfo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let rowObj = toRegisterInfo[indexPath.row]
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! RegisterUserTableViewCell
        cell.configureCellWithInfo(rowObj: rowObj)
        cell.infoTxtFld.delegate = self
        
        if(cell.infoTxtFld.placeholder?.contains("Password"))! {
            cell.infoTxtFld.isSecureTextEntry = true
        }
        return cell
    }
    
    @IBAction func createAccountAction(_ sender: UIButton) {
        
        GSConnection.shared.registerUser(userInfo: dict, completionHandler: {(error) in
            DispatchQueue.main.async {
                if(error == nil) {
                    let alertView = UIAlertController(title: "Congratulations!", message: "Account created successfully. Please continue to login in with your account", preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "Ok", style: .cancel, handler: {(action) -> Void in
                        self.dismiss(animated: true, completion: nil)
                    })
                    alertView.addAction(defaultAction)
                    self.present(alertView, animated: true, completion: nil)
                }
                else {
                    let alertView = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                    alertView.addAction(defaultAction)
                    self.present(alertView, animated: true, completion: nil)
                }
            }
        })
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if let text = textField.placeholder {
            for index in 0..<toRegisterInfo.count {
                let cell = userDetailsTable.cellForRow(at: IndexPath(row: index, section: 0)) as! RegisterUserTableViewCell
                if(text == toRegisterInfo[index].label) {
                    cell.infoLabel.isHidden = false
                }
                else {
                    cell.infoLabel.isHidden = cell.infoTxtFld.hasText ? false : true
                }
            }
        }
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if let text = textField.placeholder {
            if(text == "Mobile Number") {
                let aSet = NSCharacterSet(charactersIn:"0123456789").inverted
                let compSepByCharInSet = string.components(separatedBy: aSet)
                let numberFiltered = compSepByCharInSet.joined(separator: "")
                return string == numberFiltered
            }
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        for eachRow in toRegisterInfo {
            if let inputText = textField.text, let jsonPH = eachRow.placeHolder, let phText = textField.placeholder, let name = eachRow.name {
                if(jsonPH == phText) {
                    dict.updateValue(inputText, forKey: name)
                }
            }
        }
//        if let value = textField.text, let name = textField.placeholder {
//            dict.updateValue(value, forKey: name)
//        }
        if let fN = dict["first_name"], let lN = dict["last_name"] {
            let name = fN + " " + lN
            dict.removeValue(forKey: "first_name")
            dict.removeValue(forKey: "last_name")
            dict.updateValue(name, forKey: "name")
        }        
    }
    
}








