//
//  ViewController.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 28/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

