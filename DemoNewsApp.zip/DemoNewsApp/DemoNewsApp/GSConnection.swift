//
//  GSConnection.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 28/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import Foundation

class GSConnection {
    
    static let shared = GSConnection()
    var apiToken = ""
    
    public func requestLogin(username: String, password: String, completionHandler: @escaping(NSError?) -> ()) {
        
        let parameters: [String: String] = [
            "email": username,
            "password": password
        ]
        
        guard let userInfoJsonData = try? JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) else {
            return
        }
        let userInfoString = String(data: userInfoJsonData, encoding: .utf8)
        let userInfo = userInfoString ?? ""
        let apiRequestData = userInfo.data(using: .utf8)

        if let url = URL(string: "https://gospark.app/api/v1/login") {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = apiRequestData
            
            let task = URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
                if let responseData = data {
                    do {
                        if let jsonObj = try JSONSerialization.jsonObject(with: responseData, options: .allowFragments) as? NSDictionary {
                            if let success = jsonObj.value(forKey: "success") as? Bool, let message = jsonObj.value(forKey: "message") as? String {
                                if(!success) {
                                    completionHandler(NSError(domain: "GoSpark", code: 0, userInfo: [NSLocalizedDescriptionKey: message]))
                                }
                            }
                            if let userInfo = jsonObj.value(forKey: "user") as? [String:Any], let newsHeader = userInfo["api_token"] as? String{
                                self.apiToken = newsHeader
                                completionHandler(nil)
                            }
                        }
                    }
                    catch {
                        print(error)
                        completionHandler(NSError(domain: "GoSpark", code: 0, userInfo: [NSLocalizedDescriptionKey: error.localizedDescription]))
                    }
                }
            })
            task.resume()
        }
    }
    
    public func registerUser(userInfo: [String:String], completionHandler: @escaping(NSError?) -> ()) {
        
        guard let userInfoJsonData = try? JSONSerialization.data(withJSONObject: userInfo, options: .prettyPrinted) else {
            return
        }
        let userInfoString = String(data: userInfoJsonData, encoding: .utf8)
        let userInfo = userInfoString ?? ""
        let apiRequestData = userInfo.data(using: .utf8)
        
        if let url = URL(string: "https://gospark.app/api/v1/register") {
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("XMLHttpRequest", forHTTPHeaderField: "X-Requested-With")
            request.httpBody = apiRequestData
            
            let task = URLSession.shared.dataTask(with: request, completionHandler: {(data,response,error) in
                if let responseData = data {
                    do {
                        if let jsonObj = try JSONSerialization.jsonObject(with: responseData, options: .allowFragments) as? NSDictionary {
                            if let _ = jsonObj.value(forKey: "errors"), let message = jsonObj.value(forKey: "message") {
                                completionHandler(NSError(domain: "GoSpark", code: 0, userInfo: [NSLocalizedDescriptionKey: message]))
                            }
                            else {
                                completionHandler(nil)
                            }
                        }
                    }
                    catch {
                        print(error)
                        completionHandler(NSError(domain: "GoSpark", code: 0, userInfo: [NSLocalizedDescriptionKey: error.localizedDescription]))
                    }
                }
            })
            task.resume()
            
        }
    }
    
    public func readJson() -> NSDictionary? {
        let path = Bundle.main.path(forResource: "GSToCollectUserInfo", ofType: "json")
        if let jsonPath = path {
            do {
                let jsonData = try Data(contentsOf: URL(fileURLWithPath: jsonPath))
                
                if let layout = try JSONSerialization.jsonObject(with: jsonData, options: .mutableContainers) as? NSDictionary {
                    return layout
                }
            }
            catch {
                return nil
            }
        }
        return nil
    }
}










