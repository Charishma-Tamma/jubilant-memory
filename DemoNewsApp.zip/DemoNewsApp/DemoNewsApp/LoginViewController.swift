//
//  LoginViewController.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 28/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var emailTxtFld: UITextField!
    @IBOutlet weak var pwdLabel: UILabel!
    @IBOutlet weak var pwdTxtFld: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        prepareUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func prepareUI(){
        emailTxtFld.delegate = self
        pwdTxtFld.delegate = self
        
        loginBtn.layer.cornerRadius = 5
//        loginBtn.backgroundColor = UIColor.clear
//        let gradient = CAGradientLayer().backgroundGradientColor()
//        gradient.frame = loginBtn.bounds
//        loginBtn.layer.insertSublayer(gradient, at: 0)
    }
    
    @IBAction func loginAction(_ sender: UIButton) {
        
        if let email = emailTxtFld.text, let pwd = pwdTxtFld.text {
            GSConnection.shared.requestLogin(username: email, password: pwd, completionHandler: {(error) in
                DispatchQueue.main.async {
                    if(error == nil) {
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "newsFeedVC") as! NewsFeedViewController
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                    else {
                        let alertView = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                        let defaultAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                        alertView.addAction(defaultAction)
                        self.present(alertView, animated: true, completion: nil)
                    }
                }
            })
        }
    }
    
    @IBAction func registerUserAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "registerUserInfoVC") as! RegisterViewController
        let nav = UINavigationController(rootViewController: vc)
        self.present(nav, animated: true, completion: nil)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if let text = textField.placeholder {
            if(text == "Email/Username") {
                emailLabel.isHidden = false
                pwdLabel.isHidden = pwdTxtFld.hasText ? false : true
            }
            if(text == "Password") {
                pwdLabel.isHidden = false
                emailLabel.isHidden = emailTxtFld.hasText ? false : true
            }
        }
    }
}

extension CAGradientLayer {
    
    func backgroundGradientColor() -> CAGradientLayer {
        let topColor = UIColor(red: (0/255.0), green: (153/255.0), blue:(51/255.0), alpha: 1)
        let bottomColor = UIColor(red: (0/255.0), green: (153/255.0), blue:(255/255.0), alpha: 1)
        
        let gradientColors: [CGColor] = [topColor.cgColor, bottomColor.cgColor]
        let gradientLocations: [NSNumber] = [0, 1]
        
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        
        return gradientLayer
    }
}















