//
//  NewsFeedViewController.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 28/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import UIKit
import WebKit

class NewsFeedViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(handleLogOutAction))
        
        let url = URL(string: "https://gospark.app/api/v1/kstream")
        if let newsFeedUrl = url, let authData = GSConnection.shared.apiToken.data(using: .utf8) {
            let base64String = authData.base64EncodedString(options: [])
            var request = URLRequest(url: newsFeedUrl)
            request.httpMethod = "GET"
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue("Bearer \(base64String)", forHTTPHeaderField: "Authorization")

            webView.load(request)
        }
    }

    @objc func handleLogOutAction() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
