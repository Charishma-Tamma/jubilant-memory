//
//  GSInfoDataStructure.swift
//  DemoNewsApp
//
//  Created by Tamma Charishma on 29/09/19.
//  Copyright © 2019 Tamma Charishma. All rights reserved.
//

import Foundation

class RowObject: NSObject {
    
    var type: String?
    var label: String?
    var placeHolder: String?
    var options = [Options]()
    var name: String?
    
    init(fieldInfo: [String:Any]) {
        
        type = fieldInfo["type"] != nil ? fieldInfo["type"] as! String : ""
        label = fieldInfo["label"] != nil ? fieldInfo["label"] as! String : ""
        placeHolder = fieldInfo["placeholder"] != nil ? fieldInfo["placeholder"] as! String : ""
        name = fieldInfo["name"] != nil ? fieldInfo["name"] as! String : ""

        if let optionsValue = fieldInfo["options"] as? [[String:Any]] {
            for eachOption in optionsValue {
                options.append(Options(optionInfo: eachOption))
            }
        }
    }
}

class Options: NSObject {
    
    var label : String = ""
    
    init(optionInfo: [String:Any]){
        label = optionInfo["label"] != nil ? optionInfo["label"] as! String : ""
    }
}



